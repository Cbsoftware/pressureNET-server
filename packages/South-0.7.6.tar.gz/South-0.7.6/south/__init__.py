"""
South - Useable migrations for Django apps
"""

__version__ = "0.7.6"
__authors__ = [
    "Andrew Godwin <andrew@aeracode.org>",
    "Andy McCurdy <andy@andymccurdy.com>"
]
