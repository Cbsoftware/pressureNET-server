
Welcome to PILKit's documentation!
==================================

.. include:: ../../README.rst


Authors
=======

.. include:: ../../AUTHORS


Contents
=========

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. toctree::
   :maxdepth: 2
