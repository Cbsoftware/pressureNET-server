from storages.tests.hashpath import *
from storages.tests.s3boto import *
