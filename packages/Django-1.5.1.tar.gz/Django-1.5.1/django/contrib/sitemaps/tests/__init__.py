from .flatpages import FlatpagesSitemapTests
from .generic import GenericViewsSitemapTests
from .http import HTTPSitemapTests
from .https import HTTPSSitemapTests, HTTPSDetectionSitemapTests
