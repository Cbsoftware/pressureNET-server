from django.contrib.formtools.wizard.legacy import FormWizard
