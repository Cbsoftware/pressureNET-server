"""
Looking for processors? They have moved to PILKit. See imagekit.importers for
details.

"""
