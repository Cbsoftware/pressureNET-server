Django Grappelli
================

**A jazzy skin for the Django admin interface**.

Grappelli is a grid-based alternative/extension to the `Django <http://www.djangoproject.com>`_ administration interface.

Code
----

https://github.com/sehmaschine/django-grappelli

Documentation
-------------

http://readthedocs.org/docs/django-grappelli/

Releases
--------

* Grappelli 2.4.5 (Development Version, not yet released, see Branch Stable/2.4.x)
* Grappelli 2.4.4 (February 22 2013): Compatible with Django 1.4/1.5
* Grappelli 2.3.9 (September 06 2012): Compatible with Django 1.3

Older versions are availabe at GitHub, but are not supported anymore.
