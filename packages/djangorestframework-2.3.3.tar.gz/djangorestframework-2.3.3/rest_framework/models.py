# Just to keep things like ./manage.py test happy
