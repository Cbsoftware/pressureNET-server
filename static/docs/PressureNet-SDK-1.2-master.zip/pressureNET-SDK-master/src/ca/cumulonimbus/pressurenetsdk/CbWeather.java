package ca.cumulonimbus.pressurenetsdk;

/**
 * Parent class for all Weather
 * @author jacob
 *
 */
public class CbWeather {

	private int animateGroupNumber = 0;

	public int getAnimateGroupNumber() {
		return animateGroupNumber;
	}
	public void setAnimateGroupNumber(int animateGroupNumber) {
		this.animateGroupNumber = animateGroupNumber;
	}
}
