package ca.cumulonimbus.pressurenetsdk;

public class CbExpandedCondition extends CbCondition {

	private double temperatureC;

	public double getTemperatureC() {
		return temperatureC;
	}

	public void setTemperatureC(double temperatureC) {
		this.temperatureC = temperatureC;
	}
	
	
	
}
